#############################################################
# ZADANIE 3
#############################################################
# Przekonwertuj referencyjną mapę głębi depth.png z zadania 1 na kolorową chmurę punktów w formacie PLY.
imgPath = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z1Z2Z3/left.png"

plyPath = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/z3.ply"

img = cv2.imread(imgPath, cv2.IMREAD_COLOR)
disparityMap_ex5 = cv2.imread(disparityMapPath, cv2.IMREAD_GRAYSCALE)
depthMap_ex5 = cv2.imread(depthMapPath, cv2.IMREAD_GRAYSCALE)

h, w = depthMap_ex5.shape[:2]
if img.shape[:2] != (h, w):
    img = cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)

if disparityMap_ex5.shape[:2] != (h, w):
    disparityMap_ex5 = cv2.resize(
        disparityMap_ex5, (w, h), interpolation=cv2.INTER_AREA
    )

f = 0.8 * w  # focal length
Q = np.float32(
    [
        [1, 0, 0, -0.5 * w],
        [0, -1, 0, 0.5 * h],  # turn points 180 deg around x-axis,
        [0, 0, 0, -f],  # so that y-axis looks up
        [0, 0, 1, 0],
    ]
)

points = cv2.reprojectImageTo3D(disparityMap_ex5, Q)
colors = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
mask = depthMap_ex5 < 50

outPoints = points[mask]
outColors = colors[mask]

zw.write_ply_file(
    fileName=plyPath,
    verts=outPoints,
    colors=outColors,
)