#############################################################
# ZADANIE 1
#############################################################
# Odczytaj wartości z referencyjnej mapy głębi wygenerowanej przy użyciu symulatora CARLA (depth.png).

# Odczyt
deptMapRef_24bit = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z1Z2Z3/depth.png"

depthMap_uint24 = cv2.imread(deptMapRef_24bit, cv2.IMREAD_UNCHANGED)

# Konwersja na 8 bit
maxDepth = 1000.0  # meters

depthMap = zw.decode_depth_map(
    depthMap=depthMap_uint24,
    maxDepth=maxDepth,
    decodeDepthMapRange="24-bit",
)

# Odczytanie punktów ze zdjęcia i wyznaczenie odległości od kamery
inputFolder = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/"

inputInfoPath = inputFolder + "Z1Z2Z3/info.png"

points = [(804, 474), (1630, 273), (343, 171)]
# points = get_points(inputInfoPath)
# print(f"{points = }")

results = get_depth_value_for_points(points, depthMap, unit="m")
# print(f"{results = }")

# Kliknięto w punkt: (804, 474)
# Kliknięto w punkt: (1630, 273)
# Kliknięto w punkt: (343, 171)
# P1 (804, 474): 21.88 m
# P2 (1630, 273): 8.00 m
# P3 (343, 171): 56.01 m

# Zapis
depthMapPath = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z1depth.png"

mask = depthMap == 50
depthMap[mask] = 250

mask = depthMap > 50
depthMap[mask] = 255

cv2.imwrite(depthMapPath, depthMap)