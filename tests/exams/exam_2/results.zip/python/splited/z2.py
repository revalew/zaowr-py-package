#############################################################
# ZADANIE 2
#############################################################
# Wyznacz mapę rozbieżności (disparity map) na podstawie referencyjnej mapy głębi (depth map).

# Konwersja zdekodowanej mapy
hFOV = 90
baseline = 0.1  # meters
maxDepth = 1000.0  # meters
minDepth = 0.0  # meters
focalLength = (depthMap_uint24.shape[0] / 2) / np.tan(np.radians(hFOV) / 2)

disparityMap = zw.depth_to_disparity_map(
    depthMap=depthMap,
    baseline=baseline,
    focalLength=focalLength,
    minDepth=minDepth,
)

# Odczyt rozbieżności
results = get_disparity_value_for_points(points, disparityMap, unit="px")
# P1(804, 474): 12.00 px
# P2(1630, 273): 37.00 px
# P3(343, 171): 0.00 px

# Zapis
disparityMapPath = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z2disparity.png"

cv2.imwrite(disparityMapPath, disparityMap)