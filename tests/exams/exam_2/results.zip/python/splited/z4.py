#############################################################
# ZADANIE 4
#############################################################
# Korzystając z metody StereoSGBM udostępnionej przez bibliotekę OpenCV wyznacz mapę rozbieżności oraz mapę głębi.
img_left_path = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z4Z5/im0.png"

img_right_path = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z4Z5/im1.png"

calibrationFile = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z4Z5/calib.txt"

disparityMapRefPath = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z4Z5/disp0.pfm"


depthComparisonPath1 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z4depth.png"

disparityComparisonPath1 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z4disparity.png"

depthComparisonPath2 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z4depth_comparison.png"

disparityComparisonPath2 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z4disparity_comparison.png"

# Wczytaj kalibrację
calibrationParams = zw.load_depth_map_calibration(
    calibFile=calibrationFile
)

# Wczytaj referencyjną mapę PFM
disparityMap, scale = zw.load_pfm_file(filePath=disparityMapRefPath)

depthMap = zw.disparity_to_depth_map(
    disparityMap=disparityMap,
    baseline=calibrationParams["baseline"],
    focalLength=calibrationParams["focalLength"],
    doffs=calibrationParams["doffs"],
    aspect=1000.0,  # return depth in meters
)

depthMap_8bit = zw.depth_map_normalize(
    depthMap=depthMap, normalizeDepthMapRange="8-bit"
)

# Oblicz nową mapę dysparycji za pomocą StereoSGBM
disparityMapSGBM = zw.calculate_disparity_map(
    leftImagePath=img_left_path,
    rightImagePath=img_right_path,
    blockSize=9,
    numDisparities=256,
    minDisparity=0,
    disparityCalculationMethod="sgbm",
    normalizeDisparityMap=False,
)

disparityMapSGBM = disparityMapSGBM.astype(np.float32) / 16.0

depthMapSGBM = zw.disparity_to_depth_map(
    disparityMap=disparityMapSGBM,
    baseline=calibrationParams["baseline"],
    focalLength=calibrationParams["focalLength"],
    doffs=calibrationParams["doffs"],
    aspect=1000.0,
)

depthMapSGBM_8bit = zw.depth_map_normalize(
    depthMap=depthMapSGBM, normalizeDepthMapRange="8-bit"
)

points = [(1550, 900)]

print(f"\n\nX, Y = [{points[0][0]}, {points[0][1]}]\n\nGT:")
depth_gt = get_depth_value_for_points(points, depthMap, unit="m")
disparity_gt = get_disparity_value_for_points(points, disparityMap, unit="px")

print(f"\nSGBM:")
depth = get_depth_value_for_points(points, depthMapSGBM, unit="m")
disparity = get_disparity_value_for_points(points, disparityMapSGBM, unit="px")

cv2.imwrite(disparityComparisonPath1, disparityMapSGBM)
cv2.imwrite(depthComparisonPath1, depthMapSGBM_8bit)

zw.compare_images(
    images=[disparityMap, disparityMapSGBM],
    cmaps=["gray", "gray"],
    pltLabel="Disparity map comparison",
    titles=["Ground truth", "StereoSGBM"],
    nrows=1,
    ncols=2,
    save=True,
    savePath=disparityComparisonPath2,
)

zw.compare_images(
    images=[depthMap_8bit, depthMapSGBM_8bit],
    cmaps=["gray", "gray"],
    pltLabel="Depth map comparison",
    titles=["Ground truth", "StereoSGBM"],
    nrows=1,
    ncols=2,
    save=True,
    savePath=depthComparisonPath2,
)