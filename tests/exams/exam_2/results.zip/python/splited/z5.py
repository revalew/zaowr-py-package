#############################################################
# ZADANIE 5
#############################################################
# Korzystając z własnej implementacji metody bazującej na dopasowaniu bloków omówionej podczas wykładów wyznacz mapę rozbieżności oraz mapę głębi dla pary obrazów kanonicznego układu stereo.

# ZDJĘCIA W SKALI 0.25
img_left_path = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z4Z5/im0_4.png"

img_right_path = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/K2T1/K2T1/Z4Z5/im1_4.png"


depthComparisonPath1 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z5depth.png"

disparityComparisonPath1 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z5disparity.png"

depthComparisonPath2 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z5depth_comparison.png"

disparityComparisonPath2 = "/run/media/maks/Dokumenty 2/Studia/Infa Magister/Infa sem 2/ZAOWR Zaawansowana Analiza Obrazu, Wideo i Ruchu/KOLOS_2_2024/results/img/z5disparity_comparison.png"

# Oblicz nową mapę dysparycji za pomocą własnej implementacji
disparityMapCustom = zw.calculate_disparity_map(
    leftImagePath=img_left_path,
    rightImagePath=img_right_path,
    maxDisparity=64,
    windowSize=(5, 5),
    disparityCalculationMethod="custom",
    # normalizeDisparityMap=False,
)

depthMapCustom = zw.disparity_to_depth_map(
    disparityMap=disparityMapCustom,
    baseline=calibrationParams["baseline"],
    focalLength=calibrationParams["focalLength"],
    doffs=calibrationParams["doffs"],
    aspect=1000.0,
)

depthMapCustom_8bit = zw.depth_map_normalize(
    depthMap=depthMapCustom, normalizeDepthMapRange="8-bit"
)

points = [(1550, 900)]

print(f"\n\nX, Y = [{points[0][0]}, {points[0][1]}]\n\nGT:")
depth_gt = get_depth_value_for_points(points, depthMap, unit="m")
disparity_gt = get_disparity_value_for_points(points, disparityMap, unit="px")

points = [(int(1550 / 4), int(900 / 4))]
print(f"\nCUSTOM:")
depth = get_depth_value_for_points(points, depthMapCustom, unit="m")
disparity = get_disparity_value_for_points(points, disparityMapCustom, unit="px")

cv2.imwrite(disparityComparisonPath1, disparityMapCustom)
cv2.imwrite(depthComparisonPath1, depthMapCustom_8bit)

zw.compare_images(
    images=[disparityMap, disparityMapCustom],
    cmaps=["gray", "gray"],
    pltLabel="Disparity map comparison",
    titles=["Ground truth", "Custom"],
    nrows=1,
    ncols=2,
    save=True,
    savePath=disparityComparisonPath2,
)

zw.compare_images(
    images=[depthMap_8bit, depthMapCustom_8bit],
    cmaps=["gray", "gray"],
    pltLabel="Depth map comparison",
    titles=["Ground truth", "Custom"],
    nrows=1,
    ncols=2,
    save=True,
    savePath=depthComparisonPath2,
)