# ZAOWR Package

This is a **ZAOWR** (Zaawansowana Analiza Obrazu, Wideo i Ruchu, eng. _Advanced Image, Video, and Motion Analysis_) Python package used by me and a friend at the university.

This package has been prepared following [this tutorial](https://packaging.python.org/en/latest/tutorials/packaging-projects/).
